db = db.getSiblingDB("apinizerdb");

function waitForCollectionAndDocument() {
  while (true) {
    var collections = db.getCollectionInfos({ name: "general_settings" });
    if (collections.length > 0) {
      print("general_settings koleksiyonu var.");

      var count = db.general_settings.countDocuments({ _id: { $exists: true } });
      if (count > 0) {
        print("En az bir belge mevcut. Lisans basılıyor...");
        db.general_settings.updateOne(
          { "_class": "GeneralSettings" },
          {
            $set: {
              licenseKey: "rG3KC7l7kqzVWZy/er5XXTe+mdu0xia5Xn65ErMXXj1/RZjVLKUwkYFq3CaFabwxpliBYxcwIErBhI7Czs521tAvrtM7bUUfuu/A/EUnyoWXwG7IkVwjvm+NMPkMfbt1B5ihywLvVUYAv8rFgnAzgG8Pt/EFJtRghQHD6+1vQmEiZ32JbVbGVBow6hblbWpwd8NQqmfNlTMmasJR/46tTUIV1yqk+uO5t9QIdmYV9ZFbcrraeQqRmPowvqejAPwS+tY3jc0kv4QdaK3dRET1fla8JPhYo4XZpkIiGFyvSqVQ3+XZ+w+ufVvdgPpyMZGhDHGKqTWngwJD7njicyTOEvKoN3UZLU/trSsUVQLlCnZijED/jdmJlEkmtH6q/6Tf5s/1Q9nUy66blThKgfUZ6dSOwiwXalqAol4skmZLt+zbpCZ8+8rkq/xdrQGHC1xnr230CtJxNoi7klZ8Lne/ogPe16bJK0teEvOezhsaLp79n5P5ilymShT346muGdVNFZUUSoIzxO/ggemQmzodhRPIAurGYfY+YPrwbP4hH8q2qlrmbnl5IYZYabo8Bltt24vE63+VHOZcx9PatxvYhOIVnAC5vfcGWhr98A4h+t4RkyH7JTlrkroyc94SB2JMRGesorDI0mKSalbRLLX3NABBVpx3KrptpB/JW/ZN7wpFKynF5ELfJBvjRHPefa/wgs6MIzclOTO/4Js8R+FSK1H/QcHwQU16s52kqFB85XdpIsZgP0SKMMly84Ej/VLt__xFH8UaECgYEA7lABRDq8os3r7xxTPvPr0cKkjrN0AUGUOL3oU0rRaoJJDmNefKMc__z2rXFKCtseC3Xysb8ZdQGc3BOUbrBxHKYhQQ5ux/w5EtsmeeVhCuhJmuU9vB2uwVf/CKHlDYlmghs6plmdXq65kgemZzo5TqlpirNeqQk0nOmcHtz0wPssBosPrIrZcQaxCrvQHPuUCUXM5oMQo7wPQcD6Rs1F4p6P+08pCz19BU4mfOhcGcYfqABICHJKQ1/tHQK+Sflk7htPG3KIoUyDXssBvMIQIZRZtw8AEu1oeaJ82z5J1X251r9wRkx0Vl7Z7O69wELvTbUf/qRwwpTC+0CLLrbCyQdjz4ttSyetkbwauyQFCQFKsOBgeZG5YvLE30Qmy/f0/fBpbICDcfwSS/pfXvrJgzTvaNUDFMDcf0Ek3Lo3gCvcEx0rgoTISy9AtiFXru5uNyD+hrTvYDmq3hLDzN8ODRiQNxJ0X9K7EqFfWVcpX9lweGSoH3Hs8PElfMcPaKHAanO0jJXm1AUivLSA2VWn4lA3bFQ9St2nszNz5AlXi+5uf3b/dYRjiTOCkyEqB0YG6bF/sS53n7PNpvKxSpkXKxmuuqnYID+WGMbVq9PXxvLK+mUBcKjq6ob+oGhUbFEc8T85klTHd3D5KZuy10/C69xK+Fd/obZASElSEY+ixLaXv0YHniCsQpx1qfedE7fk2cd+du/B7zN1PjlQqOsHNWPZBDlN6TPbM="
            }
          }
        );
        print("Lisans başarıyla güncellendi.");
        break;
      } else {
        print("Belge yok, bekleniyor...");
      }
    } else {
      print("general_settings koleksiyonu yok, bekleniyor...");
    }
    sleep(15000); // 15 saniye bekle
  }
}

waitForCollectionAndDocument();

