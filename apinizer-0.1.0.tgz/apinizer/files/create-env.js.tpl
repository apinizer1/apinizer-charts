var maxRetries = 30;
var retryCount = 0;

while (retryCount < maxRetries) {
  var exists = db.getCollectionInfos({ name: "environment_settings" }).length > 0;

  if (exists) {
    print("Koleksiyon environment_settings mevcut.");

    var docExists = db.environment_settings.findOne({ _id: ObjectId("6606c315f6b08b6c3e112827") });
    print("Environment mevcut mu? Kontrol ediliyor..");

    if (!docExists) {
      print("Yeni environment ekleniyor.");
      db.environment_settings.insertOne({
        "_id": ObjectId("6606c315f6b08b6c3e112827"),
        "type": "TEST",
        "name": {{ .Values.ns.namespace | default "apigw-env" | quote }},
        "environmentKey": "apnz_gw",
        "accessUrl": "http://{{ .Values.access.ip }}:30080",
        "workerServer": {
          "environment": {{ .Values.ns.namespace | default "apigw-env" | quote }},
          "deploymentName": "worker",
          "enableHttpsPort": false,
          "replicaCount": 1,
          "cpuLimit": 1,
          "memoryLimit": 1,
          "memoryUnit": "GI",
          "envVarList": [
            { "key": "JAVA_OPTS", "value": "-server -XX:MaxRAMPercentage=75.0 -Dhttp.maxConnections=1024 -Dlog4j.formatMsgNoLookups=true", "modified": true, "readOnly": false },
            { "key": "tuneWorkerThreads", "value": "1024", "modified": true, "readOnly": false },
            { "key": "tuneWorkerMaxThreads", "value": "1024", "modified": true, "readOnly": false },
            { "key": "tuneBufferSize", "value": "16384", "modified": true, "readOnly": false },
            { "key": "tuneIoThreads", "value": "1", "modified": true, "readOnly": false },
            { "key": "tuneBacklog", "value": "10000", "modified": true, "readOnly": false },
            { "key": "tuneRoutingConnectionPoolMaxConnectionPerHost", "value": "1024", "modified": true, "readOnly": false },
            { "key": "tuneRoutingConnectionPoolMaxConnectionTotal", "value": "1024", "modified": true, "readOnly": false }
          ]
        },
        "cacheServer": {
          "environment": {{ .Values.ns.namespace | default "apigw-env" | quote }},
          "deploymentName": "cache",
          "enableHttpsPort": false,
          "replicaCount": 1,
          "cpuLimit": 1,
          "memoryLimit": 1,
          "memoryUnit": "GI",
          "envVarList": [
            { "key": "JAVA_OPTS", "value": "-server -XX:MaxRAMPercentage=75.0 -Dhttp.maxConnections=1024 -Dlog4j.formatMsgNoLookups=true", "modified": true, "readOnly": false },
            { "key": "CACHE_SERVICE_NAME", "value": "cache-http-service", "modified": true, "readOnly": false }
          ]
        },
        "workerServerService": {
          "environment": {{ .Values.ns.namespace | default "apigw-env" | quote }},
          "appPort": 0,
          "nodePort": 30080
        },
        "workerServerSSLService": {
          "protocolType": "TCP",
          "appPort": 0,
          "nodePort": 0
        },
        "cacheServerService": {
          "environment": {{ .Values.ns.namespace | default "apigw-env" | quote }},
          "appPort": 0,
          "nodePort": 0
        },
        "environmentHostAliasList": [],
        "projectIdList": [],
        "publishStatus": "PUBLISHED",
        "recipientList": [],
        "nodeNameList": [],
        "httpEnabled": true,
        "httpsEnabled": false,
        "mtlsEnabled": false,
        "jwtKey2048": {
          "jwtRsaJsonWebKeyStr": "{}"
        },
        "environmentManagementAPISettings": [
          {
            "uuid": "cd0f4712-2758-487c-a254-1e294b909a10",
            "name": {{ .Values.ns.namespace | default "apigw-env" | quote }},
            "gatewayManagementAPIUrl": {{ printf "\"http://worker-http-service.%s.svc.cluster.local:8091\"" (.Values.ns.namespace | default "apigw-env") }},
            "cacheManagementAPIUrl": {{ printf "\"http://cache-http-service.%s.svc.cluster.local:8090\"" (.Values.ns.namespace | default "apigw-env") }}
          }
        ],
        "_class": "EnvironmentSettings"
      });
    } else {
      print("Environment zaten mevcut, insert işlemi atlandı.");
    }
    break;
  } else {
    print("Koleksiyon environment_settings bulunamadı. Bekleniyor...");
    retryCount++;
    sleep(5000);  // 5 saniye bekle
  }
}

if (retryCount === maxRetries) {
  print("Koleksiyon environment_settings bulunamadı, işlem iptal edildi.");
}

